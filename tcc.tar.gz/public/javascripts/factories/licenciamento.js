var app = angular.module('licagro');

app.factory('Licenciamento', function() {
  var prefix = 'licagro_';
  var getFactory = function() {
    var db = localStorage.getItem(prefix + "licenciamento");
    return db ? JSON.parse(db) : [];
  }
  return {
    query: function(q) {
      var db = getFactory();
      return d;
    },
    get: function(id, cb) {
      var db = getFactory();

      cb(db[id]);
    },
    create: function(model, cb) {
      var db = getFactory();

      last = _.last(db);
      model.id = last ? last.id + 1 : 0;

      db[model.id] = model;
      var db = localStorage.setItem(prefix + 'licenciamento', JSON.stringify(db));

      cb(model);
    },
    update: function(model, cb) {
      var db = getFactory();
      db[model.id] = model;
      var db = localStorage.setItem(prefix + 'licenciamento', db);

      cb(model);
    },
    delete: function() {
      var db = localStorage.removeItem(prefix + 'favoriteflavor');
      return true;
    },
    paged: function(q, cb) {
      var db = getFactory();
      cb(db);
    }
  };
});