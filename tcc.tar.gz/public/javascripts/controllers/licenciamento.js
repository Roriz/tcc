var app = angular.module('licagro');

app.controller('LicenciamentoListCtrl', ['$scope', 'Licenciamento', '$location',
  function($scope, Licenciamento, $location) {

    $scope.dataGrid = {
      buttons: [{
        href: '#licenciamento/edit',
        name: 'Criar Novo',
        class: 'btn btnDefault'
      }],
      modelName: 'licenciamento',
      collection: Licenciamento,
      columnDefs: [{
        headerName: "ID",
        field: "id",
        sort: 'desc',
        hide: ISMOBILE,
        onCellClicked: function(ngGridData) {
          $scope.$apply(function() {
            $location.path('/licenciamento/show/' + ngGridData.data.id);
          })
        },
        minWidth: 70,
        maxWidth: 70,
      }, {
        headerName: "Processo",
        field: "ibram_processo",
        onCellClicked: function(ngGridData) {
          $scope.$apply(function() {
            $location.path('/licenciamento/show/' + ngGridData.data.id);
          })
        },
      }, {
        headerName: "Nome do Requerente",
        field: "tb_requerente.name",
        valueGetter: function(ngGridData) {
          return _.get(ngGridData.data, ngGridData.colDef.field);
        },
        onCellClicked: function(ngGridData) {
          $scope.$apply(function() {
            $location.path('/licenciamento/show/' + ngGridData.data.id);
          });
        },
      }, {
        headerName: "Nome do Destinatario",
        field: "tb_requerente.tb_correspondencia.name",
        hide: ISMOBILE,
        valueGetter: function(ngGridData) {
          return _.get(ngGridData.data, ngGridData.colDef.field);
        },
        onCellClicked: function(ngGridData) {
          $scope.$apply(function() {
            $location.path('/licenciamento/show/' + ngGridData.data.id);
          });
        },
      }, {
        headerName: "Localização",
        field: "tb_requerente.tb_empreendimento.localizacao",
        hide: ISMOBILE,
        valueGetter: function(ngGridData) {
          return _.get(ngGridData.data, ngGridData.colDef.field);
        },
        onCellClicked: function(ngGridData) {
          $scope.$apply(function() {
            $location.path('/licenciamento/show/' + ngGridData.data.id);
          })
        },
      }, {
        headerName: "Actions",
        field: "id",
        cellRenderer: function(params) {
          return '<a href="#licenciamento/edit/' + params.value + '" class="btn icon iconEdit btnPrimary"></a>' +
            '<a ng-click="delete(' + params.value + ', \'' + params.data.name + '\')" class="btn icon iconTrash btnDefault"></a>';
        }
      }]
    };


    $scope.delete = function(id, name, afterDelete) {
      alertify.dialog('confirm')
        .set({
          transition: 'fade',
          'title': 'Excluir',
          'message': 'Tem certeza que deseja excluir o médico ' + name + '?',
          'onok': function() {

            window.loading(true);
            Licenciamento.delete({
              id: id
            }, function() {
              window.loading(false);
              alertify.success('Médico excluido com sucesso!');
              if (afterDelete) {
                afterDelete();
              }
            });
          }
        }).show();
    };
  }
]);

app.controller('LicenciamentoShowCtrl', ['$scope', '$routeParams', 'Licenciamento', '$uibModal',
  function($scope, $routeParams, Licenciamento, $uibModal) {
    $scope.afterRender = function() {};
    $scope.model = {};
    $scope.model.id = $routeParams.id;
    Licenciamento.get($scope.model.id, function(r) {
      $scope.model = r;
    });
  }
]);


app.controller('LicenciamentoEditCtrl', ['Licenciamento', '$location', '$scope', '$routeParams', '$rootScope',
  function(Licenciamento, $location, $scope, $routeParams, $rootScope) {
    $scope.model = Licenciamento;
    $scope.situacao_imovel = JSON.parse(localStorage.getItem('situacao_imovel'));
    $scope.destino_efluente = JSON.parse(localStorage.getItem('destino_efluente'));
    $scope.fase_empreendimento = JSON.parse(localStorage.getItem('fase_empreendimento'));
    $scope.destino_lixo = JSON.parse(localStorage.getItem('destino_lixo'));
    $scope.efluente_liquido = JSON.parse(localStorage.getItem('efluente_liquido'));
    $scope.abastecimento_agua = JSON.parse(localStorage.getItem('abastecimento_agua'));
    $scope.tipo_lixo_gerado = JSON.parse(localStorage.getItem('tipo_lixo_gerado'));
    $scope.tipo_atividade = JSON.parse(localStorage.getItem('tipo_atividade'));
    $scope.tipos_licenciamento = JSON.parse(localStorage.getItem('tipos_licenciamento'));

    if ($routeParams.id) {
      Licenciamento.get($routeParams.id, function(r) {
        $scope.model = r;
      });
    }


    $scope.send = function() {
      var model = {};

      angular.copy($scope.model, model);

      window.loading(true);

      if (model.id) {
        Licenciamento.update(model, function(response) {
          $rootScope.canChangeRouter = true;
          window.loading(false);
          alertify.success('Licenciamento atualizado com sucesso!');
          if ($scope.model.new == 1) {
            $scope.model = Licenciamento;
          } else {
            $location.path("licenciamento/show/" + response.id);
          }
        });
      } else {
        Licenciamento.create(model, function(response) {
          $rootScope.canChangeRouter = true;
          window.loading(false);
          alertify.success('Licenciamento cadastrado com sucesso!');
          if ($scope.model.new == 1) {
            $scope.model = Licenciamento;
          } else {
            $location.path("licenciamento/show/" + response.id);
          }
        });
      }
    };

  }
]);